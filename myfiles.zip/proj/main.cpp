#include <iostream>
#include <fstream>
#include <map>
#include <string>

using namespace std;

// Function to read the input file and calculate item frequencies
void calculateFrequencies(map<string, int>& itemFrequencies) {
    ifstream inputFile("CS210_Project_Three_Input_File.txt");
    std::string item;

    if (inputFile.is_open()) {
        while (getline(inputFile, item)) {
            
            // Increment the frequency count for each item
            itemFrequencies[item]++;
            cout << item << " " << endl;
            //cout <<itemFrequencies[item] << endl;
        }
        inputFile.close();
    } else {
        cout << "Failed to open input file." << endl;
    }
}

// Function to print the frequency of a specific item
void printItemFrequency(map<string, int>& itemFrequencies, const std::string item) {
    cout << item;
    if (itemFrequencies[item] > 0) {
        cout << "Frequency of item " << item << ": " << itemFrequencies.at(item) << endl;
    } else {
        cout << "Item not found." << endl;
    }
}

// Function to print all item frequencies
void printAllItemFrequencies(const map<string, int>& itemFrequencies) {
    cout << "Item Frequencies:" << endl;
    for (const auto& item : itemFrequencies) {
        cout << item.second << " " << item.first << endl;
    }
}

// Function to print item frequencies as a histogram
void printItemHistogram(const map<string, int>& itemFrequencies) {
    cout << "Item Histogram:" << endl;
    for (const auto& item : itemFrequencies) {
        string opt = "";
        for(int i = 0; i < item.second; i++){
            opt += "*";
        }
        cout << opt << endl;
        cout << ""<< item.first << "";
        
    }
}

// Function to save item frequencies to a backup file
void saveItemFrequencies(const map<string, int>& itemFrequencies) {
    ofstream outputFile("frequency.dat");
    if (outputFile.is_open()) {
        for (const auto& item : itemFrequencies) {
            outputFile << item.first << " " << item.second << endl;
        }
        outputFile.close();
        cout << "Item frequencies saved to backup file." << endl;
    } else {
        cout << "Failed to create backup file." << endl;
    }
}

int main() {
    map< string, int> itemFrequencies;
    calculateFrequencies(itemFrequencies);

    int choice;
    string item;

    do {
        choice = 5;
        cout << "Menu Options:" << endl;
        cout << "1. Lookup item frequency" << endl;
        cout << "2. Print all item frequencies" << endl;
        cout << "3. Print item histogram" << endl;
        cout << "4. Save item frequencies to backup file" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice (1-5): ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter the item to lookup: ";
                cin >> item;
                printItemFrequency(itemFrequencies, item);
                break;
            case 2:
                printAllItemFrequencies(itemFrequencies);
                break;
            case 3:
                printItemHistogram(itemFrequencies);
                break;
            case 4:
                saveItemFrequencies(itemFrequencies);
                break;
            case 5:
                cout << "Exiting the program." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }

        cout << endl;
    } while (choice != 5);

    return 0;
}
